package qa.udst.ecommerce.models;

public class PhysicalProduct extends BaseProduct {
    double weight;

    public PhysicalProduct(int id, String name,double price, double weight){
        super(id, name, price);
        this.weight = weight;
    }

    @Override
    public void displayInfo() {
        System.out.println("weight: " + weight);
    }


}
