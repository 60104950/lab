package qa.udst.ecommerce.models;

public abstract class BaseProduct {
    int id;
    String name;
    double price;
    public abstract void displayInfo();

    protected BaseProduct(int id, String name, double price){
        this.id = id;
        this.name = name;
        this.price = price;
    }
}
